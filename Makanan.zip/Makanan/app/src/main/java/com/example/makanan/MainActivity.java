package com.example.makanan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class  MainActivity extends AppCompatActivity {
    private  MakanAdapter makanAdapter;
    private RecyclerView recyclerView;
    private ArrayList<Makan> makaneus;
    int jumakanan;
    private RequestQueue requestQueue;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView=findViewById(R.id.rv_menu);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        makaneus= new ArrayList<>();
        requestQueue= Volley.newRequestQueue(this);
        parseJSON();
    }

    private void parseJSON() {
        String url="http://192.168.1.2:8080/Makan/koneksi.php";
        JsonArrayRequest request= new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                jumakanan = response.length();
                try {
                    for (int i = 0; i < jumakanan; i++) {
                        JSONObject data = response.getJSONObject(i);
                        String namamakanan = data.getString("Nama");
                        String gambarmakanan = data.getString("Gambar");
                        String hargamakanan = data.getString("Harga");
                        String deskripsimakanan = data.getString("Deskripsi");
                        makaneus.add(new Makan(namamakanan, hargamakanan, gambarmakanan, deskripsimakanan));

                    }
                    makanAdapter = new MakanAdapter(MainActivity.this, makaneus);
                    recyclerView.setAdapter(makanAdapter);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
    });
       requestQueue.add(request);
    }

}