package com.example.makanan;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class MakanAdapter extends RecyclerView.Adapter<MakanAdapter.MakanViewHolder> {
        private Context context;
        private ArrayList<Makan> makaneus;

        public MakanAdapter(Context mcontext, ArrayList<Makan> menu){
            context=mcontext;
            makaneus=menu;
        }

    @NonNull
    @Override
    public MakanViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(context).inflate(R.layout.item_makan,parent,false);

            return new MakanViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MakanViewHolder holder, int position) {
            Makan makananbaru= makaneus.get(position);
            String gambarbaru= makananbaru.getGambar();
            String  harga=makananbaru.getHarga();
            String  deskripsi=makananbaru.getDeskripsi();
            String  nama=makananbaru.getNama();


            holder.tvNamabarang.setText(nama);
            holder.tvHargabarang.setText(harga);
            holder.tvDeskripsibarang.setText(deskripsi);
        Glide
            .with(context)
            .load(gambarbaru)
            .centerCrop()
            .into(holder.imdata);
    }

    @Override
    public int getItemCount() {
        return makaneus.size();
    }

    public class MakanViewHolder extends RecyclerView.ViewHolder {
        public ImageView imdata;
        public TextView  tvHargabarang;
        public TextView  tvNamabarang;
        public TextView  tvDeskripsibarang;
        public MakanViewHolder(@NonNull View itemView) {
            super(itemView);
            imdata= itemView.findViewById(R.id.IV_gambarmakan);
            tvHargabarang=itemView.findViewById(R.id.tv_Harga);
            tvNamabarang=itemView.findViewById(R.id.tv_Nama);
            tvDeskripsibarang=itemView.findViewById(R.id.tv_Deskripsi);

        }
    }


}
