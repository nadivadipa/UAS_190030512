package com.example.makanan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class   DetailActivity extends AppCompatActivity {
    TextView Tvnamakanan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        Tvnamakanan=findViewById(R.id.tv_Nama);
        Tvnamakanan.setText(getIntent().getStringExtra("Nama"));
        Tvnamakanan=findViewById(R.id.tv_Harga);
        Tvnamakanan.setText(getIntent().getStringExtra("Harga"));
        Tvnamakanan=findViewById(R.id.tv_Deskripsi);
        Tvnamakanan.setText(getIntent().getStringExtra("Deskripsi"));
    }
}